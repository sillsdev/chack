namespace Palaso.UI.WindowsForms.SuperToolTip
{
    partial class dlgSuperToolTipEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            SuperToolTipInfoWrapper superToolTipInfoWrapper1 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper2 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper3 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper4 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper5 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper6 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper14 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper8 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper7 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper12 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper9 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper10 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper11 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper13 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper18 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper15 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper17 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper16 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper32 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper19 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper20 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper22 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper21 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper24 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper23 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper31 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper25 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper26 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper27 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper28 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper29 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper30 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper33 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper34 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper41 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper36 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper35 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper40 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper37 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper38 = new SuperToolTipInfoWrapper();
            SuperToolTipInfoWrapper superToolTipInfoWrapper39 = new SuperToolTipInfoWrapper();
            this.dlgColorPicker = new System.Windows.Forms.ColorDialog();
            this.tltpHelper = new System.Windows.Forms.ToolTip(this.components);
            this.btnFooterFont = new System.Windows.Forms.Button();
            this.btnHeaderFont = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnBodyFont = new System.Windows.Forms.Button();
            this.dlgFontPicker = new System.Windows.Forms.FontDialog();
            this.dlgImagePicker = new System.Windows.Forms.OpenFileDialog();
            this.chkFooter = new System.Windows.Forms.CheckBox();
            this.chkHeader = new System.Windows.Forms.CheckBox();
            this.grpFooter = new System.Windows.Forms.GroupBox();
            this.grpFooterText = new System.Windows.Forms.GroupBox();
            this.txtFooter = new System.Windows.Forms.RichTextBox();
            this.grpFooterImage = new System.Windows.Forms.GroupBox();
            this.btnBrowseFooterImage = new System.Windows.Forms.Button();
            this.picFooterImage = new System.Windows.Forms.PictureBox();
            this.btnClearFooterImage = new System.Windows.Forms.Button();
            this.chkShowFooterSeparator = new System.Windows.Forms.CheckBox();
            this.grpHeader = new System.Windows.Forms.GroupBox();
            this.chkShowHeaderSeparator = new System.Windows.Forms.CheckBox();
            this.grpHeaderText = new System.Windows.Forms.GroupBox();
            this.txtHeader = new System.Windows.Forms.RichTextBox();
            this.grpBackgroundColor = new System.Windows.Forms.GroupBox();
            this.rdbtnCustom = new System.Windows.Forms.RadioButton();
            this.rdbtnPredefined = new System.Windows.Forms.RadioButton();
            this.grpPredefined = new System.Windows.Forms.GroupBox();
            this.cmbPredefined = new System.Windows.Forms.ComboBox();
            this.grpPreview = new System.Windows.Forms.GroupBox();
            this.pnlBackColorPreview = new System.Windows.Forms.Panel();
            this.grpCustom = new System.Windows.Forms.GroupBox();
            this.lblMiddle = new System.Windows.Forms.Label();
            this.btnBegin = new System.Windows.Forms.Button();
            this.lblBegin = new System.Windows.Forms.Label();
            this.lblEnd = new System.Windows.Forms.Label();
            this.btnEnd = new System.Windows.Forms.Button();
            this.btnMiddle = new System.Windows.Forms.Button();
            this.btnPreview = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.grpBody = new System.Windows.Forms.GroupBox();
            this.grpBodyText = new System.Windows.Forms.GroupBox();
            this.txtBody = new System.Windows.Forms.RichTextBox();
            this.grpBodyImage = new System.Windows.Forms.GroupBox();
            this.btnBrowseBodyImage = new System.Windows.Forms.Button();
            this.picBodyImage = new System.Windows.Forms.PictureBox();
            this.btnClearBodyImage = new System.Windows.Forms.Button();
            this.superToolTip1 = new SuperToolTip(this.components);
            this.grpFooter.SuspendLayout();
            this.grpFooterText.SuspendLayout();
            this.grpFooterImage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFooterImage)).BeginInit();
            this.grpHeader.SuspendLayout();
            this.grpHeaderText.SuspendLayout();
            this.grpBackgroundColor.SuspendLayout();
            this.grpPredefined.SuspendLayout();
            this.grpPreview.SuspendLayout();
            this.grpCustom.SuspendLayout();
            this.grpBody.SuspendLayout();
            this.grpBodyText.SuspendLayout();
            this.grpBodyImage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBodyImage)).BeginInit();
            this.SuspendLayout();
            // 
            // dlgColorPicker
            // 
            this.dlgColorPicker.AnyColor = true;
            this.dlgColorPicker.FullOpen = true;
            // 
            // tltpHelper
            // 
            this.tltpHelper.UseAnimation = false;
            // 
            // btnFooterFont
            // 
            this.btnFooterFont.Location = new System.Drawing.Point(211, 16);
            this.btnFooterFont.Name = "btnFooterFont";
            this.btnFooterFont.Size = new System.Drawing.Size(27, 25);
            superToolTipInfoWrapper1.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.btnFooterFont, superToolTipInfoWrapper1);
            this.btnFooterFont.TabIndex = 38;
            this.btnFooterFont.Text = "...";
            this.tltpHelper.SetToolTip(this.btnFooterFont, "Footer Font and Color Picker");
            this.btnFooterFont.UseVisualStyleBackColor = true;
            this.btnFooterFont.Click += new System.EventHandler(this.GetFont);
            // 
            // btnHeaderFont
            // 
            this.btnHeaderFont.Location = new System.Drawing.Point(211, 14);
            this.btnHeaderFont.Name = "btnHeaderFont";
            this.btnHeaderFont.Size = new System.Drawing.Size(27, 27);
            superToolTipInfoWrapper2.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.btnHeaderFont, superToolTipInfoWrapper2);
            this.btnHeaderFont.TabIndex = 37;
            this.btnHeaderFont.Text = "...";
            this.tltpHelper.SetToolTip(this.btnHeaderFont, "Header Font and Color Picker");
            this.btnHeaderFont.UseVisualStyleBackColor = true;
            this.btnHeaderFont.Click += new System.EventHandler(this.GetFont);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(353, 471);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 28);
            superToolTipInfoWrapper3.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.btnCancel, superToolTipInfoWrapper3);
            this.btnCancel.TabIndex = 27;
            this.btnCancel.Text = "Cancel";
            this.tltpHelper.SetToolTip(this.btnCancel, "123456");
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnBodyFont
            // 
            this.btnBodyFont.Location = new System.Drawing.Point(211, 12);
            this.btnBodyFont.Name = "btnBodyFont";
            this.btnBodyFont.Size = new System.Drawing.Size(27, 26);
            superToolTipInfoWrapper4.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.btnBodyFont, superToolTipInfoWrapper4);
            this.btnBodyFont.TabIndex = 36;
            this.btnBodyFont.Text = "...";
            this.tltpHelper.SetToolTip(this.btnBodyFont, "Body Font and Color Picker");
            this.btnBodyFont.UseVisualStyleBackColor = true;
            this.btnBodyFont.Click += new System.EventHandler(this.GetFont);
            // 
            // dlgFontPicker
            // 
            this.dlgFontPicker.FontMustExist = true;
            this.dlgFontPicker.ShowColor = true;
            // 
            // chkFooter
            // 
            this.chkFooter.AutoSize = true;
            this.chkFooter.Location = new System.Drawing.Point(20, 262);
            this.chkFooter.Name = "chkFooter";
            this.chkFooter.Size = new System.Drawing.Size(56, 17);
            superToolTipInfoWrapper5.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.chkFooter, superToolTipInfoWrapper5);
            this.chkFooter.TabIndex = 54;
            this.chkFooter.Text = "Footer";
            this.chkFooter.UseVisualStyleBackColor = true;
            this.chkFooter.CheckedChanged += new System.EventHandler(this.chkFooter_CheckedChanged);
            // 
            // chkHeader
            // 
            this.chkHeader.AutoSize = true;
            this.chkHeader.Location = new System.Drawing.Point(19, 384);
            this.chkHeader.Name = "chkHeader";
            this.chkHeader.Size = new System.Drawing.Size(61, 17);
            superToolTipInfoWrapper6.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.chkHeader, superToolTipInfoWrapper6);
            this.chkHeader.TabIndex = 53;
            this.chkHeader.Text = "Header";
            this.chkHeader.UseVisualStyleBackColor = true;
            this.chkHeader.CheckedChanged += new System.EventHandler(this.chkHeader_CheckedChanged);
            // 
            // grpFooter
            // 
            this.grpFooter.Controls.Add(this.grpFooterText);
            this.grpFooter.Controls.Add(this.grpFooterImage);
            this.grpFooter.Controls.Add(this.chkShowFooterSeparator);
            this.grpFooter.Location = new System.Drawing.Point(12, 263);
            this.grpFooter.Name = "grpFooter";
            this.grpFooter.Size = new System.Drawing.Size(482, 116);
            superToolTipInfoWrapper14.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.grpFooter, superToolTipInfoWrapper14);
            this.grpFooter.TabIndex = 52;
            this.grpFooter.TabStop = false;
            // 
            // grpFooterText
            // 
            this.grpFooterText.Controls.Add(this.txtFooter);
            this.grpFooterText.Controls.Add(this.btnFooterFont);
            this.grpFooterText.Location = new System.Drawing.Point(33, 9);
            this.grpFooterText.Name = "grpFooterText";
            this.grpFooterText.Size = new System.Drawing.Size(244, 85);
            superToolTipInfoWrapper8.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.grpFooterText, superToolTipInfoWrapper8);
            this.grpFooterText.TabIndex = 50;
            this.grpFooterText.TabStop = false;
            // 
            // txtFooter
            // 
            this.txtFooter.Location = new System.Drawing.Point(6, 16);
            this.txtFooter.Name = "txtFooter";
            this.txtFooter.Size = new System.Drawing.Size(199, 64);
            superToolTipInfoWrapper7.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.txtFooter, superToolTipInfoWrapper7);
            this.txtFooter.TabIndex = 44;
            this.txtFooter.Text = "";
            this.txtFooter.TextChanged += new System.EventHandler(this.OnTextSettingsChanged);
            // 
            // grpFooterImage
            // 
            this.grpFooterImage.Controls.Add(this.btnBrowseFooterImage);
            this.grpFooterImage.Controls.Add(this.picFooterImage);
            this.grpFooterImage.Controls.Add(this.btnClearFooterImage);
            this.grpFooterImage.Location = new System.Drawing.Point(283, 9);
            this.grpFooterImage.Name = "grpFooterImage";
            this.grpFooterImage.Size = new System.Drawing.Size(193, 101);
            superToolTipInfoWrapper12.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.grpFooterImage, superToolTipInfoWrapper12);
            this.grpFooterImage.TabIndex = 49;
            this.grpFooterImage.TabStop = false;
            this.grpFooterImage.Text = "Image";
            // 
            // btnBrowseFooterImage
            // 
            this.btnBrowseFooterImage.Location = new System.Drawing.Point(6, 24);
            this.btnBrowseFooterImage.Name = "btnBrowseFooterImage";
            this.btnBrowseFooterImage.Size = new System.Drawing.Size(63, 23);
            superToolTipInfoWrapper9.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.btnBrowseFooterImage, superToolTipInfoWrapper9);
            this.btnBrowseFooterImage.TabIndex = 49;
            this.btnBrowseFooterImage.Text = "Browse";
            this.btnBrowseFooterImage.UseVisualStyleBackColor = true;
            this.btnBrowseFooterImage.Click += new System.EventHandler(this.btnBrowseFooterImage_Click);
            // 
            // picFooterImage
            // 
            this.picFooterImage.Location = new System.Drawing.Point(94, 10);
            this.picFooterImage.Name = "picFooterImage";
            this.picFooterImage.Size = new System.Drawing.Size(96, 88);
            this.picFooterImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            superToolTipInfoWrapper10.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.picFooterImage, superToolTipInfoWrapper10);
            this.picFooterImage.TabIndex = 47;
            this.picFooterImage.TabStop = false;
            // 
            // btnClearFooterImage
            // 
            this.btnClearFooterImage.Location = new System.Drawing.Point(6, 53);
            this.btnClearFooterImage.Name = "btnClearFooterImage";
            this.btnClearFooterImage.Size = new System.Drawing.Size(63, 23);
            superToolTipInfoWrapper11.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.btnClearFooterImage, superToolTipInfoWrapper11);
            this.btnClearFooterImage.TabIndex = 48;
            this.btnClearFooterImage.Text = "Clear";
            this.btnClearFooterImage.UseVisualStyleBackColor = true;
            this.btnClearFooterImage.Click += new System.EventHandler(this.btnClearFooterImage_Click);
            // 
            // chkShowFooterSeparator
            // 
            this.chkShowFooterSeparator.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chkShowFooterSeparator.AutoSize = true;
            this.chkShowFooterSeparator.Location = new System.Drawing.Point(33, 96);
            this.chkShowFooterSeparator.Name = "chkShowFooterSeparator";
            this.chkShowFooterSeparator.Size = new System.Drawing.Size(135, 17);
            superToolTipInfoWrapper13.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.chkShowFooterSeparator, superToolTipInfoWrapper13);
            this.chkShowFooterSeparator.TabIndex = 48;
            this.chkShowFooterSeparator.Text = "Show Footer Separator";
            this.chkShowFooterSeparator.UseVisualStyleBackColor = true;
            this.chkShowFooterSeparator.CheckedChanged += new System.EventHandler(this.chkShowFooterSeparator_CheckedChanged);
            // 
            // grpHeader
            // 
            this.grpHeader.Controls.Add(this.chkShowHeaderSeparator);
            this.grpHeader.Controls.Add(this.grpHeaderText);
            this.grpHeader.Location = new System.Drawing.Point(12, 385);
            this.grpHeader.Name = "grpHeader";
            this.grpHeader.Size = new System.Drawing.Size(286, 114);
            superToolTipInfoWrapper18.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.grpHeader, superToolTipInfoWrapper18);
            this.grpHeader.TabIndex = 51;
            this.grpHeader.TabStop = false;
            // 
            // chkShowHeaderSeparator
            // 
            this.chkShowHeaderSeparator.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chkShowHeaderSeparator.AutoSize = true;
            this.chkShowHeaderSeparator.Location = new System.Drawing.Point(33, 93);
            this.chkShowHeaderSeparator.Name = "chkShowHeaderSeparator";
            this.chkShowHeaderSeparator.Size = new System.Drawing.Size(140, 17);
            superToolTipInfoWrapper15.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.chkShowHeaderSeparator, superToolTipInfoWrapper15);
            this.chkShowHeaderSeparator.TabIndex = 47;
            this.chkShowHeaderSeparator.Text = "Show Header Separator";
            this.chkShowHeaderSeparator.UseVisualStyleBackColor = true;
            this.chkShowHeaderSeparator.CheckedChanged += new System.EventHandler(this.chkShowHeaderSeparator_CheckedChanged);
            // 
            // grpHeaderText
            // 
            this.grpHeaderText.Controls.Add(this.txtHeader);
            this.grpHeaderText.Controls.Add(this.btnHeaderFont);
            this.grpHeaderText.Location = new System.Drawing.Point(33, 14);
            this.grpHeaderText.Name = "grpHeaderText";
            this.grpHeaderText.Size = new System.Drawing.Size(244, 77);
            superToolTipInfoWrapper17.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.grpHeaderText, superToolTipInfoWrapper17);
            this.grpHeaderText.TabIndex = 48;
            this.grpHeaderText.TabStop = false;
            // 
            // txtHeader
            // 
            this.txtHeader.Location = new System.Drawing.Point(6, 14);
            this.txtHeader.Name = "txtHeader";
            this.txtHeader.Size = new System.Drawing.Size(199, 57);
            superToolTipInfoWrapper16.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.txtHeader, superToolTipInfoWrapper16);
            this.txtHeader.TabIndex = 42;
            this.txtHeader.Text = "";
            this.txtHeader.TextChanged += new System.EventHandler(this.OnTextSettingsChanged);
            // 
            // grpBackgroundColor
            // 
            this.grpBackgroundColor.Controls.Add(this.rdbtnCustom);
            this.grpBackgroundColor.Controls.Add(this.rdbtnPredefined);
            this.grpBackgroundColor.Controls.Add(this.grpPredefined);
            this.grpBackgroundColor.Controls.Add(this.grpPreview);
            this.grpBackgroundColor.Controls.Add(this.grpCustom);
            this.grpBackgroundColor.Location = new System.Drawing.Point(12, 12);
            this.grpBackgroundColor.Name = "grpBackgroundColor";
            this.grpBackgroundColor.Size = new System.Drawing.Size(482, 123);
            superToolTipInfoWrapper32.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.grpBackgroundColor, superToolTipInfoWrapper32);
            this.grpBackgroundColor.TabIndex = 49;
            this.grpBackgroundColor.TabStop = false;
            this.grpBackgroundColor.Text = "BackgroundColor";
            // 
            // rdbtnCustom
            // 
            this.rdbtnCustom.AutoSize = true;
            this.rdbtnCustom.Checked = true;
            this.rdbtnCustom.Location = new System.Drawing.Point(13, 63);
            this.rdbtnCustom.Name = "rdbtnCustom";
            this.rdbtnCustom.Size = new System.Drawing.Size(60, 17);
            superToolTipInfoWrapper19.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.rdbtnCustom, superToolTipInfoWrapper19);
            this.rdbtnCustom.TabIndex = 50;
            this.rdbtnCustom.TabStop = true;
            this.rdbtnCustom.Text = "Custom";
            this.rdbtnCustom.UseVisualStyleBackColor = true;
            this.rdbtnCustom.CheckedChanged += new System.EventHandler(this.OnBackgroundColorSettingChanged);
            // 
            // rdbtnPredefined
            // 
            this.rdbtnPredefined.AutoSize = true;
            this.rdbtnPredefined.Location = new System.Drawing.Point(12, 15);
            this.rdbtnPredefined.Name = "rdbtnPredefined";
            this.rdbtnPredefined.Size = new System.Drawing.Size(76, 17);
            superToolTipInfoWrapper20.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.rdbtnPredefined, superToolTipInfoWrapper20);
            this.rdbtnPredefined.TabIndex = 49;
            this.rdbtnPredefined.Text = "Predefined";
            this.rdbtnPredefined.UseVisualStyleBackColor = true;
            this.rdbtnPredefined.CheckedChanged += new System.EventHandler(this.OnBackgroundColorSettingChanged);
            // 
            // grpPredefined
            // 
            this.grpPredefined.Controls.Add(this.cmbPredefined);
            this.grpPredefined.Enabled = false;
            this.grpPredefined.Location = new System.Drawing.Point(6, 15);
            this.grpPredefined.Name = "grpPredefined";
            this.grpPredefined.Size = new System.Drawing.Size(362, 46);
            superToolTipInfoWrapper22.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.grpPredefined, superToolTipInfoWrapper22);
            this.grpPredefined.TabIndex = 47;
            this.grpPredefined.TabStop = false;
            this.grpPredefined.Text = "Predefined";
            // 
            // cmbPredefined
            // 
            this.cmbPredefined.FormattingEnabled = true;
            this.cmbPredefined.Location = new System.Drawing.Point(66, 20);
            this.cmbPredefined.Name = "cmbPredefined";
            this.cmbPredefined.Size = new System.Drawing.Size(214, 21);
            superToolTipInfoWrapper21.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.cmbPredefined, superToolTipInfoWrapper21);
            this.cmbPredefined.TabIndex = 0;
            this.cmbPredefined.SelectedIndexChanged += new System.EventHandler(this.cmbPredefined_SelectedIndexChanged);
            // 
            // grpPreview
            // 
            this.grpPreview.Controls.Add(this.pnlBackColorPreview);
            this.grpPreview.Location = new System.Drawing.Point(374, 15);
            this.grpPreview.Name = "grpPreview";
            this.grpPreview.Size = new System.Drawing.Size(102, 102);
            superToolTipInfoWrapper24.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.grpPreview, superToolTipInfoWrapper24);
            this.grpPreview.TabIndex = 46;
            this.grpPreview.TabStop = false;
            this.grpPreview.Text = "Preview";
            // 
            // pnlBackColorPreview
            // 
            this.pnlBackColorPreview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlBackColorPreview.Location = new System.Drawing.Point(3, 16);
            this.pnlBackColorPreview.Name = "pnlBackColorPreview";
            this.pnlBackColorPreview.Size = new System.Drawing.Size(96, 83);
            superToolTipInfoWrapper23.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.pnlBackColorPreview, superToolTipInfoWrapper23);
            this.pnlBackColorPreview.TabIndex = 45;
            this.pnlBackColorPreview.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlBackColorPreview_Paint);
            // 
            // grpCustom
            // 
            this.grpCustom.Controls.Add(this.lblMiddle);
            this.grpCustom.Controls.Add(this.btnBegin);
            this.grpCustom.Controls.Add(this.lblBegin);
            this.grpCustom.Controls.Add(this.lblEnd);
            this.grpCustom.Controls.Add(this.btnEnd);
            this.grpCustom.Controls.Add(this.btnMiddle);
            this.grpCustom.Location = new System.Drawing.Point(6, 65);
            this.grpCustom.Name = "grpCustom";
            this.grpCustom.Size = new System.Drawing.Size(362, 49);
            superToolTipInfoWrapper31.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.grpCustom, superToolTipInfoWrapper31);
            this.grpCustom.TabIndex = 48;
            this.grpCustom.TabStop = false;
            this.grpCustom.Text = "Custom";
            // 
            // lblMiddle
            // 
            this.lblMiddle.AutoSize = true;
            this.lblMiddle.Location = new System.Drawing.Point(131, 18);
            this.lblMiddle.Name = "lblMiddle";
            this.lblMiddle.Size = new System.Drawing.Size(44, 13);
            superToolTipInfoWrapper25.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.lblMiddle, superToolTipInfoWrapper25);
            this.lblMiddle.TabIndex = 34;
            this.lblMiddle.Text = "Middle :";
            // 
            // btnBegin
            // 
            this.btnBegin.Location = new System.Drawing.Point(91, 15);
            this.btnBegin.Name = "btnBegin";
            this.btnBegin.Size = new System.Drawing.Size(24, 20);
            superToolTipInfoWrapper26.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.btnBegin, superToolTipInfoWrapper26);
            this.btnBegin.TabIndex = 29;
            this.btnBegin.Text = "...";
            this.btnBegin.UseVisualStyleBackColor = true;
            this.btnBegin.Click += new System.EventHandler(this.GetColor);
            // 
            // lblBegin
            // 
            this.lblBegin.AutoSize = true;
            this.lblBegin.Location = new System.Drawing.Point(42, 18);
            this.lblBegin.Name = "lblBegin";
            this.lblBegin.Size = new System.Drawing.Size(40, 13);
            superToolTipInfoWrapper27.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.lblBegin, superToolTipInfoWrapper27);
            this.lblBegin.TabIndex = 33;
            this.lblBegin.Text = "Begin :";
            // 
            // lblEnd
            // 
            this.lblEnd.AutoSize = true;
            this.lblEnd.Location = new System.Drawing.Point(224, 18);
            this.lblEnd.Name = "lblEnd";
            this.lblEnd.Size = new System.Drawing.Size(32, 13);
            superToolTipInfoWrapper28.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.lblEnd, superToolTipInfoWrapper28);
            this.lblEnd.TabIndex = 35;
            this.lblEnd.Text = "End :";
            // 
            // btnEnd
            // 
            this.btnEnd.Location = new System.Drawing.Point(263, 14);
            this.btnEnd.Name = "btnEnd";
            this.btnEnd.Size = new System.Drawing.Size(24, 20);
            superToolTipInfoWrapper29.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.btnEnd, superToolTipInfoWrapper29);
            this.btnEnd.TabIndex = 31;
            this.btnEnd.Text = "...";
            this.btnEnd.UseVisualStyleBackColor = true;
            this.btnEnd.Click += new System.EventHandler(this.GetColor);
            // 
            // btnMiddle
            // 
            this.btnMiddle.Location = new System.Drawing.Point(177, 15);
            this.btnMiddle.Name = "btnMiddle";
            this.btnMiddle.Size = new System.Drawing.Size(24, 20);
            superToolTipInfoWrapper30.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.btnMiddle, superToolTipInfoWrapper30);
            this.btnMiddle.TabIndex = 30;
            this.btnMiddle.Text = "...";
            this.btnMiddle.UseVisualStyleBackColor = true;
            this.btnMiddle.Click += new System.EventHandler(this.GetColor);
            // 
            // btnPreview
            // 
            this.btnPreview.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnPreview.Location = new System.Drawing.Point(353, 399);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(157, 66);
            superToolTipInfoWrapper33.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.btnPreview, superToolTipInfoWrapper33);
            this.btnPreview.TabIndex = 28;
            this.btnPreview.Text = "Hover Here to preview";
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(435, 471);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 28);
            superToolTipInfoWrapper34.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.btnOK, superToolTipInfoWrapper34);
            this.btnOK.TabIndex = 26;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            // 
            // grpBody
            // 
            this.grpBody.Controls.Add(this.grpBodyText);
            this.grpBody.Controls.Add(this.grpBodyImage);
            this.grpBody.Location = new System.Drawing.Point(12, 142);
            this.grpBody.Name = "grpBody";
            this.grpBody.Size = new System.Drawing.Size(482, 115);
            superToolTipInfoWrapper41.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.grpBody, superToolTipInfoWrapper41);
            this.grpBody.TabIndex = 50;
            this.grpBody.TabStop = false;
            this.grpBody.Text = "Body";
            // 
            // grpBodyText
            // 
            this.grpBodyText.Controls.Add(this.txtBody);
            this.grpBodyText.Controls.Add(this.btnBodyFont);
            this.grpBodyText.Location = new System.Drawing.Point(33, 9);
            this.grpBodyText.Name = "grpBodyText";
            this.grpBodyText.Size = new System.Drawing.Size(244, 100);
            superToolTipInfoWrapper36.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.grpBodyText, superToolTipInfoWrapper36);
            this.grpBodyText.TabIndex = 47;
            this.grpBodyText.TabStop = false;
            // 
            // txtBody
            // 
            this.txtBody.Location = new System.Drawing.Point(6, 12);
            this.txtBody.Name = "txtBody";
            this.txtBody.Size = new System.Drawing.Size(199, 82);
            superToolTipInfoWrapper35.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.txtBody, superToolTipInfoWrapper35);
            this.txtBody.TabIndex = 43;
            this.txtBody.Text = "";
            this.txtBody.TextChanged += new System.EventHandler(this.OnTextSettingsChanged);
            // 
            // grpBodyImage
            // 
            this.grpBodyImage.Controls.Add(this.btnBrowseBodyImage);
            this.grpBodyImage.Controls.Add(this.picBodyImage);
            this.grpBodyImage.Controls.Add(this.btnClearBodyImage);
            this.grpBodyImage.Location = new System.Drawing.Point(283, 9);
            this.grpBodyImage.Name = "grpBodyImage";
            this.grpBodyImage.Size = new System.Drawing.Size(193, 100);
            superToolTipInfoWrapper40.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.grpBodyImage, superToolTipInfoWrapper40);
            this.grpBodyImage.TabIndex = 46;
            this.grpBodyImage.TabStop = false;
            this.grpBodyImage.Text = "Image";
            // 
            // btnBrowseBodyImage
            // 
            this.btnBrowseBodyImage.Location = new System.Drawing.Point(6, 24);
            this.btnBrowseBodyImage.Name = "btnBrowseBodyImage";
            this.btnBrowseBodyImage.Size = new System.Drawing.Size(63, 23);
            superToolTipInfoWrapper37.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.btnBrowseBodyImage, superToolTipInfoWrapper37);
            this.btnBrowseBodyImage.TabIndex = 46;
            this.btnBrowseBodyImage.Text = "Browse";
            this.btnBrowseBodyImage.UseVisualStyleBackColor = true;
            this.btnBrowseBodyImage.Click += new System.EventHandler(this.btnBrowseBodyImage_Click);
            // 
            // picBodyImage
            // 
            this.picBodyImage.Location = new System.Drawing.Point(94, 12);
            this.picBodyImage.Name = "picBodyImage";
            this.picBodyImage.Size = new System.Drawing.Size(96, 82);
            this.picBodyImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            superToolTipInfoWrapper38.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.picBodyImage, superToolTipInfoWrapper38);
            this.picBodyImage.TabIndex = 44;
            this.picBodyImage.TabStop = false;
            // 
            // btnClearBodyImage
            // 
            this.btnClearBodyImage.Location = new System.Drawing.Point(6, 53);
            this.btnClearBodyImage.Name = "btnClearBodyImage";
            this.btnClearBodyImage.Size = new System.Drawing.Size(63, 23);
            superToolTipInfoWrapper39.SuperToolTipInfo = null;
            this.superToolTip1.SetSuperStuff(this.btnClearBodyImage, superToolTipInfoWrapper39);
            this.btnClearBodyImage.TabIndex = 45;
            this.btnClearBodyImage.Text = "Clear";
            this.btnClearBodyImage.UseVisualStyleBackColor = true;
            this.btnClearBodyImage.Click += new System.EventHandler(this.btnClearBodyImage_Click);
            // 
            // dlgSuperToolTipEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(511, 501);
            this.Controls.Add(this.chkFooter);
            this.Controls.Add(this.chkHeader);
            this.Controls.Add(this.grpFooter);
            this.Controls.Add(this.grpHeader);
            this.Controls.Add(this.grpBackgroundColor);
            this.Controls.Add(this.btnPreview);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.grpBody);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "dlgSuperToolTipEditor";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "SuperToolTip Editor";
            this.grpFooter.ResumeLayout(false);
            this.grpFooter.PerformLayout();
            this.grpFooterText.ResumeLayout(false);
            this.grpFooterImage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picFooterImage)).EndInit();
            this.grpHeader.ResumeLayout(false);
            this.grpHeader.PerformLayout();
            this.grpHeaderText.ResumeLayout(false);
            this.grpBackgroundColor.ResumeLayout(false);
            this.grpBackgroundColor.PerformLayout();
            this.grpPredefined.ResumeLayout(false);
            this.grpPreview.ResumeLayout(false);
            this.grpCustom.ResumeLayout(false);
            this.grpCustom.PerformLayout();
            this.grpBody.ResumeLayout(false);
            this.grpBodyText.ResumeLayout(false);
            this.grpBodyImage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBodyImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ColorDialog dlgColorPicker;
        private System.Windows.Forms.ToolTip tltpHelper;
        private System.Windows.Forms.FontDialog dlgFontPicker;
        private System.Windows.Forms.Panel pnlBackColorPreview;
        private System.Windows.Forms.Button btnFooterFont;
        private System.Windows.Forms.RichTextBox txtFooter;
        private System.Windows.Forms.Button btnHeaderFont;
        private System.Windows.Forms.Button btnBodyFont;
        private System.Windows.Forms.RichTextBox txtBody;
        private System.Windows.Forms.RichTextBox txtHeader;
        private System.Windows.Forms.Label lblBegin;
        private System.Windows.Forms.Button btnBegin;
        private System.Windows.Forms.Label lblMiddle;
        private System.Windows.Forms.Label lblEnd;
        private System.Windows.Forms.Button btnMiddle;
        private System.Windows.Forms.Button btnEnd;
        private System.Windows.Forms.CheckBox chkShowHeaderSeparator;
        private System.Windows.Forms.CheckBox chkShowFooterSeparator;
        private System.Windows.Forms.Button btnPreview;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.GroupBox grpBackgroundColor;
        private System.Windows.Forms.GroupBox grpPredefined;
        private System.Windows.Forms.GroupBox grpPreview;
        private System.Windows.Forms.ComboBox cmbPredefined;
        private System.Windows.Forms.GroupBox grpCustom;
        private System.Windows.Forms.RadioButton rdbtnCustom;
        private System.Windows.Forms.RadioButton rdbtnPredefined;
        private System.Windows.Forms.GroupBox grpBody;
        private System.Windows.Forms.PictureBox picBodyImage;
        private System.Windows.Forms.GroupBox grpHeader;
        private System.Windows.Forms.GroupBox grpFooter;
        private System.Windows.Forms.GroupBox grpBodyText;
        private System.Windows.Forms.GroupBox grpBodyImage;
        private System.Windows.Forms.Button btnClearBodyImage;
        private System.Windows.Forms.Button btnBrowseBodyImage;
        private System.Windows.Forms.OpenFileDialog dlgImagePicker;
        private System.Windows.Forms.GroupBox grpFooterImage;
        private System.Windows.Forms.Button btnBrowseFooterImage;
        private System.Windows.Forms.PictureBox picFooterImage;
        private System.Windows.Forms.Button btnClearFooterImage;
        private System.Windows.Forms.GroupBox grpFooterText;
        private System.Windows.Forms.GroupBox grpHeaderText;
        private System.Windows.Forms.CheckBox chkHeader;
        private System.Windows.Forms.CheckBox chkFooter;
        private SuperToolTip superToolTip1;
    }
}